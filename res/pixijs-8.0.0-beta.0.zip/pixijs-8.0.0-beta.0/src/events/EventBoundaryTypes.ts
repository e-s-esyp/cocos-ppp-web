import type { Container } from '../rendering/scene/Container';
import type { FederatedEventTarget } from './FederatedEventTarget';
// @ts-expect-error - used for jsdoc typedefs
import type { FederatedPointerEvent } from './FederatedPointerEvent';
// @ts-expect-error - used for jsdoc typedefs
import type { FederatedWheelEvent } from './FederatedWheelEvent';

/**
 * The tracking data for each pointer held in the state of an {@link EventBoundary}.
 *
 * ```ts
 * pressTargetsByButton: {
 *     [id: number]: FederatedEventTarget[];
 * };
 * clicksByButton: {
 *     [id: number]: {
 *         clickCount: number;
 *         target: FederatedEventTarget;
 *         timeStamp: number;
 *     };
 * };
 * overTargets: FederatedEventTarget[];
 * ```
 * @typedef {object} TrackingData
 * @property {Record.<number, FederatedEventTarget>} pressTargetsByButton - The pressed containers'
 *  propagation paths by each button of the pointer.
 * @property {Record.<number, object>} clicksByButton - Holds clicking data for each button of the pointer.
 * @property {Container[]} overTargets - The Container propagation path over which the pointer is hovering.
 */
export type TrackingData = {
    pressTargetsByButton: {
        [id: number]: FederatedEventTarget[];
    };
    clicksByButton: {
        [id: number]: {
            clickCount: number;
            target: FederatedEventTarget;
            timeStamp: number;
        }
    };
    overTargets: FederatedEventTarget[];
};

/**
 * Internal storage of an event listener in EventEmitter.
 * @ignore
 */
type EmitterListener = { fn(...args: any[]): any, context: any, once: boolean };

/**
 * Internal storage of event listeners in EventEmitter.
 * @ignore
 */
export type EmitterListeners = Record<string, EmitterListener | EmitterListener[]>;

/**
 * Fired when a mouse button (usually a mouse left-button) is pressed on the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mousedown
 * @param {FederatedPointerEvent} event - The mousedown event.
 */

/**
 * Capture phase equivalent of {@code mousedown}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mousedowncapture
 * @param {FederatedPointerEvent} event - The capture phase mousedown.
 */

/**
 * Fired when a pointer device secondary button (usually a mouse right-button) is pressed
 * on the container. Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#rightdown
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code rightdown}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#rightdowncapture
 * @param {FederatedPointerEvent} event - The rightdowncapture event.
 */

/**
 * Fired when a pointer device button (usually a mouse left-button) is released over the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseup
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code mouseup}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseupcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device secondary button (usually a mouse right-button) is released
 * over the container. Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#rightup
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code rightup}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#rightupcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device button (usually a mouse left-button) is pressed and released on
 * the container. Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * A {@code click} event fires after the {@code pointerdown} and {@code pointerup} events, in that
 * order. If the mouse is moved over another Container after the {@code pointerdown} event, the
 * {@code click} event is fired on the most specific common ancestor of the two target Containers.
 *
 * The {@code detail} property of the event is the number of clicks that occurred within a 200ms
 * window of each other upto the current click. For example, it will be {@code 2} for a double click.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#click
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code click}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#clickcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device secondary button (usually a mouse right-button) is pressed
 * and released on the container. Container's `eventMode`
 * property must be set to `static` or 'dynamic' to fire event.
 *
 * This event follows the semantics of {@code click}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#rightclick
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code rightclick}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#rightclickcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device button (usually a mouse left-button) is released outside the
 * container that initially registered a
 * [mousedown]{@link Container#event:mousedown}.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * This event is specific to the Federated Events API. It does not have a capture phase, unlike most of the
 * other events. It only bubbles to the most specific ancestor of the targets of the corresponding {@code pointerdown}
 * and {@code pointerup} events, i.e. the target of the {@code click} event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseupoutside
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code mouseupoutside}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseupoutsidecapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device secondary button (usually a mouse right-button) is released
 * outside the container that initially registered a
 * [rightdown]{@link Container#event:rightdown}.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#rightupoutside
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code rightupoutside}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#rightupoutsidecapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device (usually a mouse) is moved globally over the scene.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#globalmousemove
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device (usually a mouse) is moved while over the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mousemove
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code mousemove}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mousemovecapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device (usually a mouse) is moved onto the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseover
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code mouseover}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseovercapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when the mouse pointer is moved over a Container and its descendant's hit testing boundaries.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseenter
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code mouseenter}
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseentercapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device (usually a mouse) is moved off the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * This may be fired on a Container that was removed from the scene graph immediately after
 * a {@code mouseover} event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseout
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code mouseout}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseoutcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when the mouse pointer exits a Container and its descendants.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseleave
 * @param {FederatedPointerEvent} event
 */

/**
 * Capture phase equivalent of {@code mouseleave}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#mouseleavecapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device button is pressed on the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerdown
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code pointerdown}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerdowncapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device button is released over the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerup
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code pointerup}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerupcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when the operating system cancels a pointer event.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointercancel
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code pointercancel}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointercancelcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device button is pressed and released on the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointertap
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code pointertap}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointertapcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device button is released outside the container that initially
 * registered a [pointerdown]{@link Container#event:pointerdown}.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * This event is specific to the Federated Events API. It does not have a capture phase, unlike most of the
 * other events. It only bubbles to the most specific ancestor of the targets of the corresponding {@code pointerdown}
 * and {@code pointerup} events, i.e. the target of the {@code click} event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerupoutside
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code pointerupoutside}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerupoutsidecapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device is moved globally over the scene.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#globalpointermove
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device is moved while over the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointermove
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code pointermove}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointermovecapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device is moved onto the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerover
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code pointerover}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerovercapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when the pointer is moved over a Container and its descendant's hit testing boundaries.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerenter
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code pointerenter}
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerentercapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a pointer device is moved off the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerout
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code pointerout}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointeroutcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when the pointer leaves the hit testing boundaries of a Container and its descendants.
 *
 * This event notifies only the target and does not bubble.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerleave
 * @param {FederatedPointerEvent} event - The `pointerleave` event.
 */

/**
 * Capture phase equivalent of {@code pointerleave}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#pointerleavecapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a touch point is placed on the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchstart
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code touchstart}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchstartcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a touch point is removed from the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchend
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code touchend}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchendcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when the operating system cancels a touch.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchcancel
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code touchcancel}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchcancelcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a touch point is placed and removed from the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#tap
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code tap}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#tapcapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a touch point is removed outside of the container that initially
 * registered a [touchstart]{@link Container#event:touchstart}.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchendoutside
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code touchendoutside}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchendoutsidecapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a touch point is moved globally over the scene.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#globaltouchmove
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a touch point is moved along the container.
 * Container's `eventMode` property must be set to `static` or 'dynamic' to fire event.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchmove
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Capture phase equivalent of {@code touchmove}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#touchmovecapture
 * @param {FederatedPointerEvent} event - Event
 */

/**
 * Fired when a the user scrolls with the mouse cursor over a Container.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#wheel
 * @type {FederatedWheelEvent}
 */

/**
 * Capture phase equivalent of {@code wheel}.
 *
 * These events are propagating from the {@link EventSystem EventSystem} in @pixi/events.
 * @event Container#wheelcapture
 * @type {FederatedWheelEvent}
 */
