export enum ShaderStage
    {
    VERTEX = 1,
    FRAGMENT = 2,
    COMPUTE = 4
}
