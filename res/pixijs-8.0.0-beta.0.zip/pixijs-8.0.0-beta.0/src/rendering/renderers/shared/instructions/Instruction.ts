export interface Instruction
{
    type: string;
    action?: string;
    canBundle: boolean;
}
