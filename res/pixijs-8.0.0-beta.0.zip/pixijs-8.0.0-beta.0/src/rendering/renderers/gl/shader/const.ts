export type PRECISION = `highp` | `mediump` | `lowp`;
