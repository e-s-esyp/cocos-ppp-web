export const MAX_TEXTURES = 16;
