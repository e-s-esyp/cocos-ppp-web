export const NOOP = () =>
{
    // empty!
};
